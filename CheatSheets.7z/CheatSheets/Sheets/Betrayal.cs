﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheatSheets.Sheets
{
    public class Betrayal : Sheet
    {
        public Betrayal()
        {
            Preloads.Add("Metadata/NPC/League/Betrayal/BetrayalNinjaCopRaid");
            Preloads.Add("Metadata/Monsters/LeagueBetrayal/FortWall/FortWall");
            Preloads.Add("Metadata/Monsters/LeagueBetrayal/BetrayalOriathBlackguardMeleeChampionCartGuard");
            Preloads.Add("Metadata/Monsters/LeagueBetrayal/BetrayalCatarina");
        }
    }
}
