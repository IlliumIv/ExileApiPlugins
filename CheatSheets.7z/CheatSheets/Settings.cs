﻿using ExileCore.Shared.Interfaces;
using ExileCore.Shared.Nodes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheatSheets
{
    public class Settings : ISettings
    {
        public Settings()
        {
            ShowInHideout = new ToggleNode(true);
        }
        public ToggleNode ShowInHideout { get; set; }
        public ToggleNode Enable { get; set; } = new ToggleNode(false);
    }

}
